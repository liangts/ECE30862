package HW4a;

public class Derived extends Base {

   public Derived( ) { }

   public void f2( ) {
      System.out.println("Derived f2");
   }
}

