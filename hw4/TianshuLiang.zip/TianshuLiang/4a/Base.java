package HW4a;

public class Base {

   public Base( ) { }

   public void f1( ) {

      System.out.println("Base f1");
   }
}

